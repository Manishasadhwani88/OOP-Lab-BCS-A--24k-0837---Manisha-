#include<iostream>
using namespace std;
class Student{
	private:
	string name;
	int rollNumber;
	double marks;
	char grade;
	public:
	Student(string n , int r_n, double m){
	name= n;
	rollNumber=r_n;
	marks=m;	
	}
	char calculateGrade(double m){
    if(m>=90 && m<=100){
    return	grade = 'A';
	}	
	else if(m>=80 && m<90){
	return	grade='B';
	}	
	else if(m>=70 && m<80){
	return 	grade='C';
	}
	else 
	return grade='F';
	}
	void displayStudentInfo(){
	cout<<"\nStudent's Info\n";
	cout<<"Name of student is: "<<name;
	cout<<"\nRoll number: " <<rollNumber;
	cout<<"\nMarks: "<<marks;
	cout<<"\nGrade: "<<grade;	
	}	
};

int main(){
	Student s1("manisha",8370,95);
	Student s2("Abeela", 1543,89);
	cout<<"The grade of 1st student is: "<<s1.calculateGrade(95)<<endl;
	s1.displayStudentInfo();
	cout<<"\nThe grade of 2nd student is: "<<s2.calculateGrade(89)<<endl;
	s2.displayStudentInfo();
	
	return 0;
}
