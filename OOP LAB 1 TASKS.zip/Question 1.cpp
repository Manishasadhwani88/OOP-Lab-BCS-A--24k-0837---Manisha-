#include<iostream>
using namespace std;
class Student{
	public:
	string name;
	int rollNumber;
		
};
int main(){
	Student s;
	s.name="manisha";
	s.rollNumber= 8370;
	cout<<"The name of student is : "<<s.name<<endl;
	cout<<"The roll number of student is :  "<<s.rollNumber;
	return 0;
}
