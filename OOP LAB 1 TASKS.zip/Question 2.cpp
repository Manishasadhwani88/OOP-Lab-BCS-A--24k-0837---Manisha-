#include<iostream>
using namespace std;
class Student{
	private:
	int rollNumber;
	public:
	string name;
	void setRollNo(int r_n){
		rollNumber = r_n;
	}
	int getRollNo(){
		return rollNumber;
	}
		
};
int main(){
	Student s;
	int rollNumber;
	s.name="manisha";
	s.setRollNo(8370);
	cout<<"The name of student is : "<<s.name<<endl;
	cout<<"The roll number of student is :  "<<s.getRollNo();
	return 0;
}
