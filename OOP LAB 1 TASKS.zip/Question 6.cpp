#include<iostream>
using namespace std;

class vehicle {
	public:
		string make;
		string model;
		void displayInfo(){
			cout<<"Make: "<<make<<", Model: "<<model<<endl;
			
		}
};
class Car : public vehicle{
	public:
		string engineType;
		void displayInfo(){
			vehicle:: displayInfo();
			cout<<"Engine type: "<<engineType<<endl;
		}
};
int main(){
	Car c1;
	c1.make="Mercedes";
	c1.model="Supra";
	c1.engineType="Turbo Charged";
	
    c1.displayInfo();
	
	return 0;
}
