#include<iostream>
using namespace std;
class concrete{
	private:
	string message ;
	public:
	concrete(string m){
	message = m;	
	}	
	void displayMessage(){
	cout<<message<<endl;	
	}
	
};
int main(){
	concrete con("Happy coding!");
	con.displayMessage();
	return 0;
}
